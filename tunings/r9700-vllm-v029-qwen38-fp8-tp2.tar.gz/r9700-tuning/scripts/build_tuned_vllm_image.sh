#!/usr/bin/env bash
set -euo pipefail

# Build a derived vLLM image with the tuning configs that match:
#   exact base-image reference + exact model name
#
# Run this script as the same user that owns the Podman image store, e.g.:
#   sudo -u vllm -H /var/lib/vllm/r9700-tuning/scripts/build_tuned_vllm_image.sh \
#       --image docker.io/vllm/vllm-openai-rocm@sha256:e5e47f6aaab675c252c381f0dac237b31b10d87bb74d092b07fb4065efd7f5a1 \
#       --model Qwen/Qwen3.8-27B-FP8 \
#       --tag localhost/vllm-r9700:qwen38-tuned
#
# Optional:
#   --root /var/lib/vllm/r9700-tuning
#   --tp-size 2
#
# The script refuses ambiguous matches.

ROOT="/var/lib/vllm/r9700-tuning"
IMAGE=""
MODEL=""
TAG=""
TP_SIZE=""

usage() {
  cat <<'EOF'
Usage:
  build_tuned_vllm_image.sh --image IMAGE --model MODEL [options]

Required:
  --image IMAGE       Exact base image reference stored in metadata.json
  --model MODEL       Exact model identifier stored in metadata.json

Options:
  --tag TAG           Output image tag.
                      Default: localhost/vllm-r9700:tuned-<12-char-hash>
  --root DIR          Tuning root. Default: /var/lib/vllm/r9700-tuning
  --tp-size N         Optional compatibility check (recommended).
  -h, --help          Show this help.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --image) IMAGE="${2:?missing value}"; shift 2 ;;
    --model) MODEL="${2:?missing value}"; shift 2 ;;
    --tag) TAG="${2:?missing value}"; shift 2 ;;
    --root) ROOT="${2:?missing value}"; shift 2 ;;
    --tp-size) TP_SIZE="${2:?missing value}"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

[[ -n "$IMAGE" ]] || { echo "--image is required" >&2; exit 2; }
[[ -n "$MODEL" ]] || { echo "--model is required" >&2; exit 2; }
[[ "$IMAGE" == *@sha256:* ]] || {
  echo "--image must be an immutable repository digest (…@sha256:…)." >&2
  exit 2
}
[[ -d "$ROOT/configs" ]] || {
  echo "No configs directory found at: $ROOT/configs" >&2
  exit 1
}

# Find an exact metadata match. Python avoids fragile grep/JSON parsing.
MATCH="$(
python3 - "$ROOT/configs" "$IMAGE" "$MODEL" "$TP_SIZE" <<'PY'
import json
import sys
from pathlib import Path

configs = Path(sys.argv[1])
image = sys.argv[2]
model = sys.argv[3]
tp_arg = sys.argv[4]
tp = int(tp_arg) if tp_arg else None

matches = []
for meta_path in configs.glob("*/metadata.json"):
    try:
        meta = json.loads(meta_path.read_text())
    except Exception:
        continue

    ident = meta.get("identity", {})
    compat = meta.get("compatibility", {})

    if ident.get("base_image") != image:
        continue
    if ident.get("model") != model:
        continue
    if tp is not None and compat.get("tp_size") != tp:
        continue
    if meta.get("tuning_status") not in (None, "complete"):
        print(f"ERROR: tuning set is not complete ({meta.get('tuning_status')}) in {meta_path}; rerun tune first.", file=sys.stderr)
        sys.exit(5)
    if meta.get("last_run_failures", 0):
        print(f"ERROR: incomplete tuning run in {meta_path}; rerun tune first.", file=sys.stderr)
        sys.exit(5)

    matches.append(meta_path.parent)

if not matches:
    print(
        "ERROR: no tuning set matches the requested image/model"
        + (f"/TP={tp}" if tp is not None else ""),
        file=sys.stderr,
    )
    sys.exit(3)

if len(matches) > 1:
    print("ERROR: multiple tuning sets match:", file=sys.stderr)
    for m in matches:
        print(f"  {m}", file=sys.stderr)
    print("Pass --tp-size or clean up duplicate metadata sets.", file=sys.stderr)
    sys.exit(4)

print(matches[0])
PY
)"

echo "Selected tuning set:"
echo "  $MATCH"

python3 "$ROOT/scripts/verify_published_configs.py" "$MATCH"

JSON_COUNT="$(find "$MATCH" -maxdepth 1 -type f -name '*.json' ! -name 'metadata.json' | wc -l)"
if [[ "$JSON_COUNT" -eq 0 ]]; then
  echo "No tuning JSON files found in $MATCH" >&2
  exit 1
fi

if [[ -z "$TAG" ]]; then
  HASH="$(
    printf '%s\0%s' "$IMAGE" "$MODEL" | sha256sum | awk '{print substr($1,1,12)}'
  )"
  TAG="localhost/vllm-r9700:tuned-$HASH"
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

mkdir -p "$TMP/configs"
find "$MATCH" -maxdepth 1 -type f -name '*.json' ! -name metadata.json -exec cp {} "$TMP/configs/" \;
cp "$MATCH/metadata.json" "$TMP/metadata.json"

# Locate vLLM without importing its GPU-dependent modules during the build.
CONFIG_DIR="$(podman run --rm --pull=never --entrypoint python3 "$IMAGE" -c \
  'import importlib.util; from pathlib import Path; p = Path(importlib.util.find_spec("vllm").origin).resolve().parent / "model_executor/layers/quantization/utils/configs"; assert p.is_dir(), p; print(p)')"
[[ "$CONFIG_DIR" == /* && "$CONFIG_DIR" != *$'\n'* && "$CONFIG_DIR" != *' '* ]] || {
  echo "Invalid vLLM config directory: $CONFIG_DIR" >&2; exit 1;
}

cat >"$TMP/Containerfile" <<EOF
FROM ${IMAGE}

COPY configs/*.json ${CONFIG_DIR}/
COPY metadata.json /opt/r9700-tuning/metadata.json

LABEL io.local.r9700-tuning.base-image="${IMAGE}"
LABEL io.local.r9700-tuning.model="${MODEL}"
EOF

echo
echo "Building:"
echo "  Base image : $IMAGE"
echo "  Model      : $MODEL"
[[ -n "$TP_SIZE" ]] && echo "  TP check   : $TP_SIZE"
echo "  Configs    : $JSON_COUNT"
echo "  Output tag : $TAG"
echo

podman build --pull=never -t "$TAG" -f "$TMP/Containerfile" "$TMP"

echo
echo "Built successfully:"
echo "  $TAG"
echo
echo "Verify with:"
echo "  podman run --rm --entrypoint /bin/bash '$TAG' -lc \\"
echo "    'cat /opt/r9700-tuning/metadata.json && ls -1 ${CONFIG_DIR}/*R9700*'"
