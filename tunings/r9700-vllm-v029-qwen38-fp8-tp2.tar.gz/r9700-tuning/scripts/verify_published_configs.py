#!/usr/bin/env python3
"""Validate the published vLLM FP8 tuning set without requiring a GPU."""

from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path


EXPECTED_IMAGE = (
    "docker.io/vllm/vllm-openai-rocm@sha256:"
    "e5e47f6aaab675c252c381f0dac237b31b10d87bb74d092b07fb4065efd7f5a1"
)
EXPECTED_MODEL = "Qwen/Qwen3.8-27B-FP8"
EXPECTED_M = [1, 2, 4, 8, 16, 24, 32, 48, 64, 96, 128, 256, 512,
              1024, 1536, 2048, 3072, 4096]
EXPECTED_FIELDS = {
    "BLOCK_SIZE_M",
    "BLOCK_SIZE_N",
    "BLOCK_SIZE_K",
    "GROUP_SIZE_M",
    "num_warps",
    "num_stages",
}
FILENAME_RE = re.compile(
    r"^N=(\d+),K=(\d+),device_name=AMD_Radeon_R9700,"
    r"dtype=fp8_w8a8,block_shape=\[128,128\]\.json$"
)


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    default_dir = (
        Path(__file__).resolve().parents[1]
        / "configs"
        / "vllm-openai-rocm_v0.29.0__Qwen3.8-27B-FP8__e5e47f6aaab6"
    )
    set_dir = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else default_dir

    metadata = json.loads((set_dir / "metadata.json").read_text())
    if metadata.get("identity", {}).get("base_image") != EXPECTED_IMAGE:
        fail("unexpected base-image identity")
    if metadata.get("identity", {}).get("model") != EXPECTED_MODEL:
        fail("unexpected model identity")
    if metadata.get("tuning_status") != "complete":
        fail("tuning set is not marked complete")

    expected_shapes = {
        (item["N"], item["K"])
        for item in metadata.get("compatibility", {}).get("shapes", [])
    }
    seen_shapes: set[tuple[int, int]] = set()
    config_files = sorted(set_dir.glob("N=*.json"))
    if len(config_files) != 5:
        fail(f"expected 5 tuning files, found {len(config_files)}")

    for path in config_files:
        match = FILENAME_RE.match(path.name)
        if not match:
            fail(f"unexpected tuning filename: {path.name}")
        seen_shapes.add((int(match.group(1)), int(match.group(2))))

        payload = json.loads(path.read_text())
        m_values = sorted(int(value) for value in payload)
        if m_values != EXPECTED_M:
            fail(f"unexpected M profile in {path.name}: {m_values}")
        for m_value, config in payload.items():
            if set(config) != EXPECTED_FIELDS:
                fail(f"unexpected fields in {path.name}, M={m_value}")
            if not all(isinstance(value, int) and value > 0
                       for value in config.values()):
                fail(f"invalid value in {path.name}, M={m_value}")

    if seen_shapes != expected_shapes:
        fail(f"shape mismatch: files={seen_shapes}, metadata={expected_shapes}")

    checksum_lines = (set_dir / "SHA256SUMS").read_text().splitlines()
    expected_hashes = dict(line.split("  ", 1) for line in checksum_lines if line)
    if set(expected_hashes.values()) != {path.name for path in config_files}:
        fail("SHA256SUMS does not enumerate exactly the five configs")
    for expected_hash, filename in expected_hashes.items():
        actual_hash = sha256(set_dir / filename)
        if actual_hash != expected_hash:
            fail(f"checksum mismatch for {filename}")

    print(
        f"PASS: {len(config_files)} shapes, "
        f"{len(EXPECTED_M)} M values each, {len(config_files) * len(EXPECTED_M)} "
        "validated tuning entries"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
