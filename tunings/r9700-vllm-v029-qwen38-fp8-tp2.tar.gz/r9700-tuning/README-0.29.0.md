# R9700-Tuning für vLLM 0.29.0 / ROCm 7.2.x

Diese Branch-Vorbereitung zielt auf AMD Radeon AI PRO R9700 (`gfx1201`) mit
`Qwen/Qwen3.8-27B-FP8`, FP8 W8A8 Block-Quantisierung, Tensor Parallelism 2 und
MTP mit zwei speculative tokens. Der Attention-Backend wird produktiv nicht
explizit gesetzt; die hier veröffentlichten Dateien tunen ausschließlich die
FP8-W8A8-GEMMs.

## Festgelegte Identität

- Basis: `docker.io/vllm/vllm-openai-rocm:v0.29.0`
- erwarteter Digest: `sha256:e5e47f6aaab675c252c381f0dac237b31b10d87bb74d092b07fb4065efd7f5a1`
- Modell: `Qwen/Qwen3.8-27B-FP8`
- GPU/Architektur: Radeon R9700 / `gfx1201`
- ROCm/HIP: `7.2.x`
- FP8: `fp8_w8a8`, Blockgröße `[128,128]`
- TP: `2`
- produktiver Attention-Backend: vLLM-Default, nicht explizit gesetzt
- produktives RCCL/NCCL-Protokoll: `NCCL_PROTO=Simple`
- Speculative Decoding: `{"method":"mtp","num_speculative_tokens":2}`

Der Wrapper zieht zunächst den Release-Tag, löst ihn einmal in einen
Repository-Digest auf und verwendet danach nur diese unveränderliche Referenz.
Wenn der aufgelöste Digest vom festgelegten Wert abweicht, den Lauf abbrechen
und die Ursache prüfen.

## Veröffentlichter Tuning-Satz

Der versionsgebundene Ordner
`configs/vllm-openai-rocm_v0.29.0__Qwen3.8-27B-FP8__e5e47f6aaab6`
enthält fünf GEMM-Formen mit jeweils 18 M-Profilen, insgesamt 90 Einträge. Der
Satz wurde am 13. September 2026 unter dem oben genannten v0.29.0-Digest neu
gemessen. Dabei blieben alle bereits bekannten Siegerkonfigurationen erhalten;
die Ergebnisdateien sind daher bytegleich mit dem Seed. Das ist im
`metadata.json` ausdrücklich dokumentiert und mit `SHA256SUMS` abgesichert.

Die Kandidaten-Zeitmessungen wurden nicht als Log archiviert. Deshalb wird
keine konkrete Beschleunigung gegenüber dem vLLM-Default behauptet. Die
Strukturprüfung ist reproduzierbar:

```bash
python3 r9700-tuning/scripts/verify_published_configs.py
```

## Checkout

Der echte Checkout liegt unter `/var/lib/vllm/r9700-vllm-tuning`; die Skripte
liegen darunter in `r9700-tuning/`. Die Befehle sind absichtlich mit einem
expliziten Benutzer und einer absoluten Skriptauflösung dokumentiert:

```bash
sudo install -d -o vllm -g vllm /var/lib/vllm
sudo -u vllm -H git clone \
  --branch codex/v0.29.0-tuning \
  git@github.com:FA85/r9700-vllm-tuning.git \
  /var/lib/vllm/r9700-vllm-tuning
sudo -u vllm -H git -C /var/lib/vllm/r9700-vllm-tuning status --short --branch
```

Für Updates nur den neuen Branch verwenden:

```bash
sudo -u vllm -H git -C /var/lib/vllm/r9700-vllm-tuning pull --ff-only
```

## Preflight, Tuning und Build

`preflight` prüft im Release-Image vLLM 0.29.0, ROCm/HIP 7.2.x, `gfx1201`,
die v0.29.0-FP8-Kernelsignatur und eine nichttriviale Rechnung für M=1/5/64.
Der Preflight ist GPU-gebunden und wird nicht als bestanden dokumentiert, wenn
er nicht auf dem R9700 ausgeführt wurde.

```bash
export TUNING_ROOT=/var/lib/vllm/r9700-vllm-tuning
sudo -u vllm -H bash \
  "$TUNING_ROOT/r9700-tuning/scripts/run_vllm_0_29_0.sh" preflight

sudo -u vllm -H bash \
  "$TUNING_ROOT/r9700-tuning/scripts/run_vllm_0_29_0.sh" tune \
  --profile all --search-space fast --retune

sudo -u vllm -H bash \
  "$TUNING_ROOT/r9700-tuning/scripts/run_vllm_0_29_0.sh" build
```

`SEED_FROM=auto` nimmt höchstens einen kompatiblen, abgeschlossenen Satz als
Startpunkt. Jeder Seed wird im neuen Digest-Verzeichnis erneut gemessen und
bleibt bis dahin untrusted. Für eine Messung ohne Seed:

```bash
sudo -u vllm -H env SEED_FROM=none bash \
  "$TUNING_ROOT/r9700-tuning/scripts/run_vllm_0_29_0.sh" tune \
  --profile all --search-space fast
```

Die Tuning-Fehlerbehandlung überspringt nur einen isolierten, synchronisierbar
fehlgeschlagenen Kandidaten. Schlägt die GPU-Synchronisation fehl, wird der Lauf
abgebrochen; ein GPU-/RCCL-Fehler wird nicht als harmloser Kandidatenfehler
verschluckt.

## Serverstart

Cache, abgeleitetes Image, Container und Benchmark-Ergebnisse haben getrennte
v0.29.0-Namen. Ein möglicher produktiver Start ist:

```bash
sudo install -d -o vllm -g vllm \
  /var/lib/vllm/vllm-0.29.0-cache/vllm \
  /var/lib/vllm/vllm-0.29.0-cache/triton \
  /var/lib/vllm/vllm-0.29.0-cache/torchinductor

sudo -u vllm -H env XDG_RUNTIME_DIR=/run/user/987 \
  podman run -d --pull=never \
  --name qwen38-0.29.0 \
  --network host --ipc host \
  --device /dev/kfd --device /dev/dri \
  --group-add keep-groups \
  --security-opt seccomp=unconfined \
  -v /var/lib/vllm/huggingface:/root/.cache/huggingface \
  -v /var/lib/vllm/vllm-0.29.0-cache/vllm:/root/.cache/vllm \
  -v /var/lib/vllm/vllm-0.29.0-cache/triton:/root/.triton \
  -v /var/lib/vllm/vllm-0.29.0-cache/torchinductor:/root/.cache/torchinductor \
  -e TRITON_CACHE_DIR=/root/.triton \
  -e TORCHINDUCTOR_CACHE_DIR=/root/.cache/torchinductor \
  -e HIP_VISIBLE_DEVICES=0,1 \
  -e PYTHONUNBUFFERED=1 \
  -e NCCL_PROTO=Simple \
  -e VLLM_EXECUTE_MODEL_TIMEOUT_SECONDS=1800 \
  localhost/vllm-r9700:qwen38-v0.29.0-tuned \
  Qwen/Qwen3.8-27B-FP8 \
    --port 8001 \
    --tensor-parallel-size 2 --kv-cache-memory-bytes 5000000000 \
    --max-num-seqs 4 --max-model-len 131072 \
    --max-num-batched-tokens 9216 --gpu-memory-utilization 0.9 \
    --mamba-cache-mode none \
    --enable-auto-tool-choice --tool-call-parser qwen3_coder \
    --reasoning-parser qwen3 \
    --speculative-config '{"method":"mtp","num_speculative_tokens":2}' \
    --enable-per-request-metrics --enable-prompt-tokens-details \
    --per-request-spec-decode-metrics summary
```

## Stress und Benchmark

Alle Stress-Runner lösen ihre Skriptpfade relativ zur jeweiligen Datei auf und
schreiben standardmäßig in neue v0.29.0-Verzeichnisse. Sie verwenden weiterhin
`NCCL_PROTO=Simple` im TP=2-RCCL-Test:

```bash
bash "$TUNING_ROOT/r9700-tuning/scripts/run_stress_fp8_m5.sh"
bash "$TUNING_ROOT/r9700-tuning/scripts/run_stress_fp8_m5_cudagraph.sh"
bash "$TUNING_ROOT/r9700-tuning/scripts/run_stress_fp8_decode_switch.sh"
bash "$TUNING_ROOT/r9700-tuning/scripts/run_stress_fp8_tp2_decode_switch.sh"

bash "$TUNING_ROOT/r9700-tuning/scripts/benchmark_vllm.sh" \
  --container qwen38-0.29.0 \
  --result-root /var/lib/vllm/profiles/benchmarks/v0.29.0-tuned \
  --runs 3
```

Ein Benchmark- oder Stressfehler beendet den jeweiligen Workflow; Rohdaten und
Logs bleiben im ausgegebenen Zeitstempelverzeichnis. Default- und Tuned-Läufe
müssen dieselben Modell-, Server-, Prompt- und Cache-Bedingungen verwenden.

## Kombination mit den R9700-Fixes

Die allgemeinen AITER-/ROCr-Fixes werden separat unter
<https://github.com/FA85/r9700-vllm-rocm72-fixes> veröffentlicht. So bleiben
die modellabhängigen GEMM-Konfigurationen von den allgemeinen Laufzeitpatches
getrennt. Für ein kombiniertes lokales Image zunächst dieses Tuning-Image bauen
und es anschließend als `BASE_IMAGE` für den Fix-Build verwenden.

```bash
sudo -u vllm -H bash \
  "$TUNING_ROOT/r9700-tuning/scripts/run_vllm_0_29_0.sh" build

git clone https://github.com/FA85/r9700-vllm-rocm72-fixes.git
cd r9700-vllm-rocm72-fixes
podman build --pull=false \
  --build-arg BASE_IMAGE=localhost/vllm-r9700:qwen38-v0.29.0-tuned \
  -t localhost/vllm-r9700:qwen38-v0.29.0-tuned-minimal-fixes .
```

## Optionaler AITER-Testpfad

Der AITER-Pfad wird nicht automatisch aktiviert und verändert weder das
produktive Image noch die Standard-Serverargumente. Er nutzt den gültigen
Backendnamen `ROCM_AITER_UNIFIED_ATTN` und eine getrennte Cache-/Container-
Identität:

```bash
bash "$TUNING_ROOT/r9700-tuning/scripts/run_aiter_smoke_v0_29_0.sh" probe
bash "$TUNING_ROOT/r9700-tuning/scripts/run_aiter_smoke_v0_29_0.sh" serve
```

`probe` prüft nur, ob Backend und AITER-Modul im Image sichtbar sind. `serve`
startet einen kurzlebigen separaten Testcontainer auf Port 8002; ein Fehler ist
ein AITER-Ergebnis und darf nicht als produktiver Triton-Fehler interpretiert
werden. Für AITER gelten dieselben R9700-/ROCm- und MTP-Anforderungen, aber die
Ergebnisse müssen separat gemessen und dokumentiert werden.

## Status und offene Prüfungen

```bash
sudo -u vllm -H git -C /var/lib/vllm/r9700-vllm-tuning status --short --branch
sudo grep -E '"tuning_status"|"last_run_failures"|"seeded_entries"' \
  /var/lib/vllm/r9700-vllm-tuning/r9700-tuning/configs/SET/metadata.json
```

Veröffentlicht sind fünf vollständige Formen mit je 18 M-Werten. Die Dateien
wurden unter v0.29.0 neu gemessen und anschließend in einem laufenden
R9700/vLLM-Setup verwendet. Ein per-Kandidat-Zeitprotokoll und ein neuer,
kontrollierter Default-vs.-Tuned-Durchsatzbenchmark sind nicht enthalten und
werden daher nicht behauptet. Die allgemeinen Idle-/LDS-Fixes gehören zum
separaten Fix-Repository.

Quelle: <https://github.com/vllm-project/vllm/releases/tag/v0.29.0>
